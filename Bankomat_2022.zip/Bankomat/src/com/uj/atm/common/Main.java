package com.uj.atm.common;

import com.uj.atm.common.Account;
import com.uj.atm.interfaces.IAccount;

public class Main {

    public static void main(String[] args) {

    }
}
