package com.uj.atm.common;

import com.uj.atm.interfaces.IAccount;
import com.uj.atm.interfaces.ICreditCard;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;


/**
 * UWAGA:
 * 1. Nie wolno tworzyć publicznych pól, jedynie można używać metod z interface
 * 2. Nie wolno dopisywać własnych metod
 * 3. Nie wolno modyfikować interface
 * 4. Nie wolno zmieniać wersji javy ani junita.
 * 5. Nie wolno tworzyć nowych (własnych) konstruktorów. Można używać jedynie istniejących (bezparametrowych).
 */
public class CreditCard implements ICreditCard {

    public CreditCard() {

    }

    @Override
    public void Init(String newPin, String newPinConfirm) {
        throw new NotImplementedException();
    }

    @Override
    public boolean ChangePin(String oldPin, String newPin, String newPinConfirm) {
        throw new NotImplementedException();
    }

    @Override
    public boolean IsPinValid(String pin) {
        throw new NotImplementedException();
    }

    @Override
    public void AddAccount(IAccount account) {
        throw new NotImplementedException();
    }

    @Override
    public IAccount GetAccount(){
        throw new NotImplementedException();
    }
    @Override
    public boolean DepositFunds(double amount) {
        throw new NotImplementedException();
    }

    @Override
    public boolean WithdrawFunds(double amount) {
        throw new NotImplementedException();
    }
}
