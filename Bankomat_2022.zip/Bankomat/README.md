**PROJEKT „BANKOMAT&quot; – INSTRUKCJA**

W celu wykonania zadania **musisz zaimplementować każdy interfejs** znajdujący się w katalogu Bankomat/src/com/uj/atm/interfaces/ Interfejsy, które należy zaimplementować to:

- **IAccount** – interfejs zawierający metody obsługujące konto bankowe
- **IAtm** – interfejs zawierający metody obsługujące działanie bankomatu
- **ICreditCard** – interfejs zawierający metody obsługujące funkcje karty płatniczej

Nie wolno tworzyć żadnej innej metody publicznej, która nie implementuje interfejsu.  Każda z metod w interfejsie posiada opis funkcjonalny, na którego podstawie powinieneś/powinnaś wykonać implementację danej metody.

Integralną częścią projektu jest stworzenie testów do zaimplementowanych przez Ciebie metod interfejsu.

**Projekt**

Projekt został stworzony w środowisku InteliJ. W celu pobrania darmowej wersji dla uczniów należy zalogować się mailem w domenie edu:

[https://www.jetbrains.com/community/education/#students](https://www.jetbrains.com/community/education/#students)

**Testy**

**Każda z metod w interfejsie**** musi mieć do siebie napisane testy**, które będą testowały poprawność zaimplementowanych metod. Pamiętaj, aby testy nie były „trywialne&quot;, tzn. nie sprawdzały wyłącznie oczywistych rzeczy. Testy powinny być na tyle mocne, aby być w stanie wykryć jak najwięcej możliwych błędów, jakie mógłby popełnić programista podczas implementacji metod.

Testy musisz wykonać w technologii  **JUnit 4**. 

Proszę użyć JUnita w projekcie InteliJ – przykład jest opisany w filmiku pod adresem:

[https://www.youtube.com/watch?v=Bld3644bIAo&amp;ab\_channel=BrianFraser](https://www.youtube.com/watch?v=Bld3644bIAo&amp;ab_channel=BrianFraser)

Testy muszą odnosić się  **tylko do metod z interfejsu**. Celem zadania jest wykonanie testów, które będą kompatybilne w stosunku do innego projektu stosującego ten sam interfejs.  Testy mogą badać poprawność działania całego programu, ale tylko na podstawie metod z interfejsu.

**Wymagania biznesowe**

System składa się z obiektów trzech typów: **konto**, **karta kredytowa**, **bankomat**.

**Konto**. Każde konto posiada nieujemne saldo.

**Karta kredytowa**. Każda karta kredytowa posiada swój kod PIN i może być stowarzyszona z co najwyżej jednym kontem. Po stowarzyszeniu karty z kontem nie jest możliwa zmiana tego konta (stowarzyszenie z kontem jest permanentne). Pin jest wartością numeryczną złożoną z dokładnie czterech znaków, np. 1234. Domyślny PIN dla nowej karty to 0000.

**Bankomat**. Bankomat realizuje operacje: 1) logowania się przy pomocy kodu PIN, 2) sprawdzania salda na koncie stowarzyszonym z daną kartą, 3) możliwość zmiany kodu PIN na karcie, 4) funkcję wpłatomatu realizującą wpłatę na konto stowarzyszone z daną kartą, 5) funkcję wypłaty pieniędzy z konta stowarzyszonego z daną kartą, 6) funkcję przelewu środków z konta stowarzyszonego z kartą na inne konto.

**Uwagi ogólne dotyczące funkcjonalności systemu**

Wszystkie funkcjonalności systemu są opisane w komentarzach do kodu interfejsu. Podczas pisania testów korzystaj tylko i wyłącznie z metod dostępnych w interfejsie (tak, aby Twoje testy mogły być wykonane na analogicznym projekcie zaimplementowanym przez inną osobę). W klasie main nie wpisuj nic.

Realizacja każdej z dostępnych funkcjonalności powinna powodować poprawność stanu wszystkich obiektów związanych z daną operacją. Na przykład: przelew z konta stowarzyszonego z daną kartą na inne powinien powodować zmniejszenie salda pierwszego konta i powiększenie salda drugiego konta o tę samą wartość; udana wypłata danej kwoty w bankomacie powinna skutkować zmniejszeniem salda konta stowarzyszonego z kartą, przy pomocy której operacja jest realizowana, o tę samą kwotę; z konta o ujemnym saldzie nie można wypłacać pieniędzy; itd. Generalnie, powinny być zachowane (i przetestowane) wszystkie „zdroworozsądkowe&quot; zasady korzystania z kart, kont i bankomatów znane Ci z codziennej praktyki.

**Uwagi końcowe**

Podczas wykonywania zadania możesz korzystać z informacji (np. znalezionych w sieci) dotyczących kwestii technicznych, programistycznych, tego jak wykorzystać dane narzędzie itp. **Ważne jest jednak, abyś zadanie wykonał/a samodzielnie. Nie wyszukuj w Internecie przykładowych rozwiązań implementacji kodu bądź testów w podobnych projektach – kod i testy twórz samodzielnie. Nie konsultuj się z innymi studentami, którzy również biorą udział w tym zadaniu. Nie przesyłaj innym studentom żadnych informacji, jakie uzyskasz od osób prowadzących projekt**. Jeśli będziesz mieć jakieś problemy podczas wykonywania zadania i będziesz potrzebował/a pomocy, zwróć się do osoby nadzorującej projekt (michal.mnich@uj.edu.pl). Wyniki uzyskane przez studentów będą podlegały badaniom naukowym i dlatego ważne jest, aby nie były zaburzone poprzez komunikowanie się z innymi osobami biorącymi udział w eksperymencie.


**Wysyłanie porjektu**

Projekt należy wysłać prowadzącemu (michal.mnich@uj.edu.pl) w formie spakowanego pliku: "ImieNazwisko.zip".
